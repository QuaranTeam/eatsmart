eatsmart allows you to create daily meal plans, recipes, and  shopping lists easily to keep you healthy and safe, while eliminating waste.
